import React from 'react';

const BookmarkDetail = () => {
  return (
    <div>
      
    </div>
  );
};

export default BookmarkDetail;