import React from 'react';

const PlaylistPopup = () => {
  return (
    <div>
      
    </div>
  );
};

export default PlaylistPopup;