import React from 'react';

const MusicDetail = () => {
  return (
    <div>
      
    </div>
  );
};

export default MusicDetail;