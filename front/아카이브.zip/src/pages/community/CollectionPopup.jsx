import React from 'react';

const CollectionPopup = () => {
  return (
    <div>
      
    </div>
  );
};

export default CollectionPopup;