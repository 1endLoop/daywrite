import React from 'react';

const NoticeWrite = () => {
  return (
    <div>
      
    </div>
  );
};

export default NoticeWrite;