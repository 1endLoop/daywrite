import styled from "styled-components";
const C={}

C.InfoCard = styled.div`
  background: #f2f2f2;
  padding: 18px;
  border-radius: 12px;
  display: flex;
  gap: 8px;
  font-size: 18px;
  position:relaive;
  margin-top:20px;
`;

export default C;